create view V_AGENT_TOTAL as
  select m.order_no,
       m.user_id,
       nvl(ua.real_name, ua.telphone) as user_name,
       u.parent_id,
       nvl(CHECK_BRAND_ID, d.brand_id) as brand_id,
       nvl(CHECK_BRAND_NAME, d.brand_name) as brand_name,
       nvl(CHECK_DEVICE_ID, d.device_id) as device_id,
       nvl(CHECK_DEVICE_MODEL, d.device_model) as device_model,
       DEVICE_PICTURE_ID,
       SERIAL_NUMBER,
       nvl(FINALLY_AMOUNT, 0) as FINALLY_AMOUNT,
       CHECK_DATE,
       REAL_NAME,
       TRADE_TYPE,
       DISCOUNT_AMOUNT,
       STORE_ID,
       s.name as store_name,
       ORDER_STATUS
  from t_order_detail d,
       t_order_main   m,
       t_store        s,
       t_users        u,
       t_user_account ua
 where d.order_id = m.order_no
   and m.user_id = u.id
   and u.user_type = 2
   and m.store_id = s.uuid(+)
   and ua.user_id = u.id
   and m.order_status in(5, 12)
union
select m.order_no,
       m.store_user,
       nvl(ua.real_name, ua.telphone) as user_name,
       u.parent_id,
       nvl(CHECK_BRAND_ID, d.brand_id) as brand_id,
       nvl(CHECK_BRAND_NAME, d.brand_name) as brand_name,
       nvl(CHECK_DEVICE_ID, d.device_id) as device_id,
       nvl(CHECK_DEVICE_MODEL, d.device_model) as device_model,
       DEVICE_PICTURE_ID,
       SERIAL_NUMBER,
       nvl(FINALLY_AMOUNT, 0) as FINALLY_AMOUNT,
       CHECK_DATE,
       REAL_NAME,
       TRADE_TYPE,
       DISCOUNT_AMOUNT,
       STORE_ID,
       s.name as store_name,
       ORDER_STATUS
  from t_order_detail d,
       t_order_main   m,
       t_users        u,
       t_store        s,
       t_user_account ua
 where d.order_id = m.order_no
   and m.store_user = u.id
   and u.user_type = 2
   and m.store_id = s.uuid(+)
   and ua.user_id = u.id
   and m.order_status in(5, 12)
/

