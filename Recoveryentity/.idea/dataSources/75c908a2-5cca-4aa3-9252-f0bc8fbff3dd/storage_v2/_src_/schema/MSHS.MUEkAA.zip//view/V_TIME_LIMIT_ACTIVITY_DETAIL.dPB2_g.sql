create view V_TIME_LIMIT_ACTIVITY_DETAIL as
  SELECT ad.UUID,
       ad.ACTIVITY_ID,
       ad.BRAND_ID,
       B.BRAND_NAME,
       ad.DEVICE_ID,
       d.device_model,
       F.ID AS PICTURE_ID,
       D.MAX_PRICE,
       d.min_price,
       ad.VIEW_ORDER,
       ad.CREATED_BY,
       ad.CREATION_DATE,
       ad.LAST_UPDATE_BY,
       ad.LAST_UPDATE_DATE,
       ad.EXT_FIELD1,
       ad.EXT_FIELD2,
       ad.MEMO
  FROM T_UPLOAD_FILES F,
        T_RECOVERY_DEVICE D,
        T_TIME_LIMIT_ACTIVITY_DETAIL ad,
        T_RECOVERY_BRAND B
WHERE F.PARENT_ID(+) = D.UUID AND B.UUID = D.BRAND_ID AND D.UUID = ad.DEVICE_ID AND B.UUID = ad.BRAND_ID
ORDER BY ad.VIEW_ORDER
/

