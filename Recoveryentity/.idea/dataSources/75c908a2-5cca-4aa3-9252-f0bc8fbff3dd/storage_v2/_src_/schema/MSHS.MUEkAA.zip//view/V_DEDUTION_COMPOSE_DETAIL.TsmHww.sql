create view V_DEDUTION_COMPOSE_DETAIL as
  select cd.uuid,
       cd.compose_id,
       cd.item_id,
       cd.created_by,
       cd.creation_date,
       cd.last_update_by,
       cd.last_update_date,
       cd.ext_field1,
       cd.ext_field2,
       cd.memo,
       ci.category_id,
       ci.category_name,
       ci.category_type,
       ci.os,
       ci.item_NAME,
       ci.item_code,
       ci.picture_id,
       ci.view_order
  from T_DEDUTION_COMPOSE_DETAIL cd, v_recovery_check_item ci
 where cd.item_id = ci.uuid
/

