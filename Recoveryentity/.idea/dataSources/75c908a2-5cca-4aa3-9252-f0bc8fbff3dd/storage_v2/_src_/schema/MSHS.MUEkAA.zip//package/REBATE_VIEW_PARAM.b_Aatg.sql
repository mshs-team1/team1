create package rebate_view_param  is 
   --参数一
   function set_start_date(start_date in varchar2) return varchar2; 
   function get_start_date return varchar2;

   --参数二
   function set_end_date(end_date in varchar2) return varchar2; 
   function get_end_date return varchar2;

end rebate_view_param;
/

