create package body rebate_view_param is
       p_start_date varchar2(20);
       p_end_date varchar2(20);

       function set_start_date(start_date in varchar2) return varchar2 is
       begin
         p_start_date:=start_date;
         return p_start_date;
        end;

       function get_start_date return varchar2 is
       begin
         return p_start_date;
       end;

       function set_end_date(end_date in varchar2) return varchar2 is
       begin
         p_end_date:=end_date;
         return p_end_date;
        end;

       function get_end_date return varchar2 is
       begin
         return p_end_date;
       end;
   end rebate_view_param;
/

