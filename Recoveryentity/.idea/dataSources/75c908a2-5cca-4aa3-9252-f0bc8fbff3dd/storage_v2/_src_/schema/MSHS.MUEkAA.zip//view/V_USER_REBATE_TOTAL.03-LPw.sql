create view V_USER_REBATE_TOTAL as
  select t."USER_ID",t."USER_NAME",t."PARENT_ID",t."REAL_NAME",t."FIRST_FINALLY_AMOUNT",t."FIRST_REBATE",t."SECOND_FINALLY_AMOUNT",t."SECOND_REBATE",t."THIRD_FINALLY_AMOUNT",t."THIRD_REBATE", (first_rebate + second_rebate + third_rebate) as total_rebate
from(
select user_id, user_name, parent_id, REAL_name,
    sum(first_finally_amount) as first_finally_amount, sum(first_rebate) as first_rebate,
    sum(second_finally_amount) as second_finally_amount, sum(second_rebate) as second_rebate,
    sum(third_finally_amount) as third_finally_amount, sum(third_rebate) as third_rebate
from (
select ua.user_id, nvl(ua.REAL_name, ua.login_name) as user_name, ua.parent_id, ua.real_name,
       sum(r.FINALLY_AMOUNT) as first_finally_amount, sum(first_rebate) as first_rebate,
       0 as second_finally_amount, 0 as second_rebate, 0 as third_finally_amount, 0 as third_rebate
from v_user_account ua, t_order_rebate r
where ua.user_id = first_user and substr(r.creation_date, 1, 10) >= rebate_view_param.get_start_date() and substr(r.creation_date, 1, 10) <= rebate_view_param.get_end_date()
group by ua.user_id, ua.REAL_name, ua.login_name, ua.parent_id
union
select ua.user_id, nvl(ua.REAL_name, ua.login_name) as user_name, ua.parent_id, ua.real_name,
       0 as first_finally_amount, 0 as first_rebate,
       sum(r.FINALLY_AMOUNT) as second_finally_amount, sum(second_rebate) as second_rebate,
     0 as third_finally_amount, 0 as third_rebate
from v_user_account ua, t_order_rebate r
where substr(r.creation_date, 1, 10) >= rebate_view_param.get_start_date() and substr(r.creation_date, 1, 10) <= rebate_view_param.get_end_date() and ua.user_id = second_user
group by ua.user_id, ua.REAL_name, ua.login_name, ua.parent_id
union
select ua.user_id, nvl(ua.REAL_name, ua.login_name) as user_name, ua.parent_id, ua.real_name,
       0 as first_finally_amount, 0 as first_rebate,
       0 as second_finally_amount, 0 as second_rebate,
     sum(r.FINALLY_AMOUNT) as third_finally_amount, sum(third_rebate) as third_rebate
from v_user_account ua, t_order_rebate r
where substr(r.creation_date, 1, 10) >= rebate_view_param.get_start_date() and substr(r.creation_date, 1, 10) <= rebate_view_param.get_end_date() and ua.user_id = third_user
group by ua.user_id, ua.REAL_name, ua.login_name, ua.parent_id
)
group by user_id, user_name, parent_id, real_name
) t
/

